# 
# data <- read.csv(here::here('tutorial/plasma_data.csv'), row.names=1) %>% as.matrix()
# metadata <- read.csv(here::here('tutorial/plasma_metadata.csv'), row.names=1)

context('test-plasma.R')

test_that(desc = 'testing SCRuB variations on plasma dataset',
          {
            if( torch::torch_is_installed() == F){
                      torch::install_torch()
                      detach('package:SCRuB', unload=TRUE)
                      detach('package:torch', unload=TRUE)
                      library(SCRuB)
                      library(torch) 
                      }
            n_feats_considered=100 # to avoid memory errors on GHA
            data <- (read.csv( paste0( test_path(), '/plasma_data.csv'), row.names=1) %>% as.matrix() )[,1:n_feats_considered]
            metadata <- read.csv( paste0( test_path(), '/plasma_metadata.csv'), row.names=1)
            
            set.seed(1)
            scr_out_1 <- SCRuB( data[, 1:n_feats_considered], metadata, c("control blank DNA extraction", "control blank library prep") )
            scr_out_2 <- SCRuB( data[, 1:n_feats_considered], metadata[,1:2], "control blank library prep") 
            scr_out_2 <- SCRuB( data[, 1:n_feats_considered], metadata[,1:2],  c("control blank DNA extraction", "control blank library prep") ) 
           
            print('Testing shortened data')
            scr_out_3 <- SCRuB( 100*data[c(1:50, 81, 54), 1:n_feats_considered], metadata[c(1:50, 81, 54),], verbose=T) 
            scr_out_3 <- SCRuB( data[c(1:50, 81, 54), 1:n_feats_considered], metadata[c(1:50, 81, 54),], verbose=F) 
            scr_out_3 <- SCRuB( 100*data[c(1:50, 80), 1:n_feats_considered], metadata[c(1:50, 80),1:2], verbose=F) 
            
            
            scr_out_4 <- SCRuB(input_data = paste0(test_path(), '/small_table.biom'), paste0(test_path(), '/plasma_metadata.csv'))
            
            ## testing the manually specified list of control leakers as an input
            manual_leaker_override <- list('12692.Control.1'=c("12667.X3097210",
                                                               "12667.X2342267"),
                                           "12691.Control.44"=c("12667.X2056691",
                                                                "12691.PC14", 
                                                                "12667.X2105130",
                                                                "12692.150178" ) )
            scr_out_5 <- SCRuB( data[, 1:n_feats_considered], metadata, manual_leaker_override=manual_leaker_override)
            
            ## adding check for different column types in metadata
            tmp_metadata <- metadata
            tmp_metadata$sample_type <- as.factor(tmp_metadata$sample_type)
            tmp_metadata$sample_well <- as.factor(tmp_metadata$sample_well)
            scr_out_2 <- SCRuB( data[, 1:n_feats_considered], tmp_metadata,  c("control blank DNA extraction", "control blank library prep") ) 
            
            expect_type(scr_out_1, 'list')
            expect_type(scr_out_1$inner_iterations,  'list' )
            
            print(nrow(scr_out_1$decontaminated_samples) )
            
            expect_true( nrow(scr_out_1$decontaminated_samples) == sum( F == metadata$is_control ) )
            expect_true( nrow(scr_out_1$decontaminated_samples) == length(scr_out_1$p))
            expect_true( length(scr_out_1$inner_iterations$`control blank DNA extraction`$gamma) == n_feats_considered )
            expect_true( sum(scr_out_1$inner_iterations$`control blank DNA extraction`$gamma) %>% round(5) == 1 )
            expect_true( scr_out_1$inner_iterations$`control blank DNA extraction`$alpha %>% rowSums() %>% mean() %>% round(5) == 1 )
            expect_true( min( colnames(data)[1:n_feats_considered] == colnames(scr_out_1$decontaminated_samples)) == T )
            expect_true( min( colnames(data)[1:n_feats_considered] == colnames(scr_out_2$decontaminated_samples)) == T )
            
            ## error checks
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[51:100,]) )
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[1:50,],  rep("control blank library prep", 2)) )
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[1:50,],  c("control blank library prep", 'fake control')) )
            metadata$sample_well[1] <- 'B16'
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[1:50,] ) )
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[1:50,], NA ) )
            expect_error( SCRuB( data[1:50, 1:n_feats_considered], metadata[1:50,], c('control blank library prep', NA ) ) )
            expect_error( SCRuB( 0*data[1:50, 1:n_feats_considered], metadata[1:50,], c('control blank library prep', NA ) ) )
          })


